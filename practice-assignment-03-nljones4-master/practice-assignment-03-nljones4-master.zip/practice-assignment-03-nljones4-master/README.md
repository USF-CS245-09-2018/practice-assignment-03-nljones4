# CS 245 (Fall, 2018) PracticeAssignment02

See assignment details on Canvas.
